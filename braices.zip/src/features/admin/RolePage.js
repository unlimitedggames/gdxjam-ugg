import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import { PageHeader } from '../common/PageHeader';
import { Maintainance } from '../common/Maintainance';
import { Input } from 'antd';

const columns = [
  {
    title: 'Id',
    name: 'idRol',
    sort: 'number',
    filter: false,
  },
  {
    title: 'Nombre',
    name: 'nombre',
    sort: 'string',
    filter: false,
  },
];

const commonFields = [
  {
    name: 'idRol',
    label: 'Id',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el id',
      },
    ],
  },
  {
    name: 'nombre',
    label: 'Nombre',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el nombre',
      },
    ],
  },
];

const formConfig = {
  options: {
    insert: {
      title: 'Agregar rol',
      skipFields: ['idRol'],
    },
    update: {
      title: 'Editar rol',
      disabledFields: ['idRol'],
    },
    delete: {
      title: 'Eliminar rol',
    },
  },
  fields: {
    insert: commonFields,
    update: commonFields,
    delete: commonFields,
  },
};

export class RolePage extends Component {
  static propTypes = {
    admin: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
  };

  render() {
    return (
      <div className="admin-role-page">
        <Maintainance
          header={'Roles'}
          fecthUrl="http://10.233.181.30:8080/RealState/roles"
          operationUrl="http://10.233.181.30:8080/RealState/roles"
          rowId="idRol"
          columns={columns}
          formConfig={formConfig}
        />
      </div>
    );
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    admin: state.admin,
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...actions }, dispatch),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(RolePage);
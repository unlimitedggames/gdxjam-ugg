import {
  DefaultPage,
  RolePage,
} from './';

import {
  AdminLayout
} from '../common/AdminLayout';

export default {
  path: 'admin',
  name: 'Admin',
  component: AdminLayout,
  childRoutes: [
    { path: '', name: 'Default page', component: DefaultPage, isIndex: true },
    { path: 'roles', name: 'Role page', component: RolePage },
  ],
};
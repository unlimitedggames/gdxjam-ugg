import React, { Component } from 'react';
import { PageHeader } from '../common/PageHeader';
import { Maintainance } from '../common/Maintainance';
import { Input, Checkbox } from 'antd';

const columns = [
  {
    title: 'Id',
    name: 'idtabla',
    sort: 'number',
    filter: false,
  },
  {
    title: 'Nombre',
    name: 'Tabla',
    sort: 'string',
    filter: false,
  },
  {
    title: 'Activo',
    name: 'activo',
    sort: 'boolean',
    filter: false,
  },
];

const commonFields = [
  {
    name: 'idtabla',
    label: 'Id',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el id',
      },
    ],
  },
  {
    name: 'Tabla',
    label: 'Nombre',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el nombre',
      },
    ],
  },
   {
    name: 'activo',
    label: 'Activo',
    element: <Checkbox  />
  },
];

const formConfig = {
  options: {
    insert: {
      title: 'Agregar tabla',
      skipFields: ['idtabla'],
    },
    update: {
      title: 'Editar tabla',
      disabledFields: ['idtabla'],
    },
    delete: {
      title: 'Eliminar tabla',
    },
  },
  fields: {
    insert: commonFields,
    update: commonFields,
    delete: commonFields,
  },
};

export default class TableCachePage extends Component {
  static propTypes = {};

  render() {
    return (
      <div className="catalogs-table-cache-page">
        <Maintainance
          header={'Tabla Maestra'}
          fecthUrl="http://10.233.181.30:8080/RealState/TableCache"
          operationUrl="http://10.233.181.30:8080/RealState/TableCache"
          rowId="idtabla"
          columns={columns}
          formConfig={formConfig}
        />
      </div>
    );
  }
}


import {
  DefaultPage,
  TableCachePage,
} from './';


import {
  AdminLayout
} from '../common/AdminLayout';

export default {
  path: 'catalogs',
  name: 'Catalogs',
  component: AdminLayout,
  childRoutes: [
    { path: 'default-page', name: 'Default page', component: DefaultPage, isIndex: true },
    { path: 'tableCache', name: 'Table cache page', component: TableCachePage },
  ],
};
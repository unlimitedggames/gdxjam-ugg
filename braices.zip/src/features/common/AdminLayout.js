import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Affix, Layout } from 'antd';
import { SideMenu, AdminMenu } from './';

const { Content, Footer } = Layout;

export class AdminLayout extends Component {
  static propTypes = {
    children: PropTypes.node,
  };

  render() {
    return (
      <div>
      <Layout style={{ minHeight: '100vh' }}>
        <Affix>
        <AdminMenu />
        </Affix>
        <Layout>
          <SideMenu /> 
          <Content>
            <div style={{ minHeight: 360 }}>
              {this.props.children}
            </div>
          </Content>
        </Layout>
      </Layout>
      </div>
    );
  }
}
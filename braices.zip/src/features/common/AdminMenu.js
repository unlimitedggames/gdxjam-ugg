import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import { Button, Layout } from 'antd';
import { Redirect } from 'react-router-dom';
import { Logout } from './Logout';

const { Header } = Layout;

export class AdminMenu extends Component {
  static propTypes = {
    common: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.bool.isRequired,
  };

  render() {
    const { isAuthenticated } = this.props;
    if (!isAuthenticated) {
      return <Redirect to="/home/login" />;
    } else {
      return (
        <Header style={{ background: '#fff', padding: '0 16px 0 16px' }}>
          <div style={{ float: 'right' }}>
            <Button
              icon="question"
              shape="circle"
              style={{ fontSize: 18, marginRight: 12, marginTop: 18 }}
            />
            {isAuthenticated && (
              <Logout onLogOutClick={() => this.props.actions.logOut()} divClass="logout-right" />
            )}
          </div>
        </Header>
      );
    }
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    common: state.common,
    isAuthenticated: state.common.isAuthenticated,
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...actions }, dispatch),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(AdminMenu);
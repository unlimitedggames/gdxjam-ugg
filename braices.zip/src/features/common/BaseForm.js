import React, { Component } from 'react';
import { Form, Button, Card, Spin, message, Divider } from 'antd';
import reqwest from 'reqwest';

const FormItem = Form.Item;

const formItemLayout = {
  labelCol: {
    xs: { span: 8 },
    sm: { span: 6 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 18 },
  },
};

const tailFormItemLayout = {
  wrapperCol: {
    xs: {
      span: 24,
      offset: 0,
    },
    sm: {
      span: 18,
      offset: 6,
    },
  },
};

export class BaseForm extends Component {
  formVars = {
    method: 'post',
  };

  state = {
    submitting: false,
    loading: false
  };

  changeMode(newMode) {
    if (newMode === 'insert') {
      this.formVars.method = 'post';
    } else if (newMode === 'update') {
      this.formVars.method = 'put';
    } else if (newMode === 'delete') {
      this.formVars.method = 'delete';
    }
  }

  componentDidMount(){
    let props = this.props;
    if (props.currentMode === 'insert') {
        this.changeMode(props.currentMode);
      } else if (props.currentMode === 'update') {
        this.changeMode(props.currentMode);
        this.fetch(props);
      } else if (props.currentMode === 'delete') {
        this.changeMode(props.currentMode);
        this.fetch(props);
      }
  }

  /*componentWillReceiveProps(props) {
    console.log('Metodo nuevo: ', props.currentMode);
    if (this.props.currentId !== props.currentId || this.props.currentMode !== props.currentMode) {
      console.log('Metodo nuevo: ', props.currentMode);

      if (props.currentMode === 'insert') {
        this.changeMode(props.currentMode);
      } else if (props.currentMode === 'update') {
        this.changeMode(props.currentMode);
        this.fetch(props);
      } else if (props.currentMode === 'delete') {
        this.changeMode(props.currentMode);
        this.fetch(props);
      }
      console.log('Metodo de formVars: ', this.formVars.method);
    }
  }*/

  fetch = (props, params = {}) => {
    const fetchUrl = this.props.operationUrl + '/' + props.currentId;
    console.log('Form fetching url: ', fetchUrl);
    this.setState({ loading: true });

    reqwest({
      url: fetchUrl,
      method: 'get',
      data: {
        ...params,
      },
      type: 'json',
    }).then(
      data => {
        this.setState({
          loading: false,
        });
        console.log('Initial data: ', data);
        for (var key in data) {
          var attrName = key;
          var attrValue = data[key];
          this.props.form.setFields({
            [attrName]: { value: [attrValue] },
          });
        }
      },

      error => {
        message.error('No fue posible cargar el registro', 5);
        console.log('Error!', error);
      },
    );
  };

  handleSubmit = e => {
    e.preventDefault();

    this.props.form.validateFieldsAndScroll((err, values) => {
      console.log('Valores del form', values);
      console.log('method: ', this.formVars.method);

      if (!err) {
        this.setState({ submitting: true });

        reqwest({
          url: this.props.operationUrl,
          method: this.formVars.method,
          data: values,
        })
          .then(
            result => {
              message.success('Realizado exitosamente', 3);
              this.props.refreshHandler();
              this.handleDefault();
              
            },
            error => {
              message.error('Ha ocurrido un error', 5);
              console.log('Error!', error);
            },
          )
          .always(() => {
            this.setState({ submitting: false });
          });
      }
    });
  };

  handleDefault = () => {
    this.props.form.resetFields();
    this.props.cancelHandler();
  };

  constructFields(mode) {
    const { getFieldDecorator } = this.props.form;
    let options = this.props.formConfig.options;
    let fields = this.props.formConfig.fields[mode];
    let modeOptions = options[mode];
    let constructedForm = null;

    for (var i = 0; i < fields.length; i++) {
      let field = fields[i];
      let fieldName = field['name'];
      let shouldSkip = false;
      let shouldDisable = false;
      let element = field['element'];

      if (modeOptions !== undefined) {
        if (modeOptions['skipFields'] !== undefined) {
          shouldSkip = modeOptions['skipFields'].includes(fieldName);
        }

        if (modeOptions['disabledFields'] !== undefined) {
          shouldDisable = modeOptions['disabledFields'].includes(fieldName);
        }
      }

      if (mode === 'delete') {
        shouldDisable = true;
      }

      if(shouldDisable){
        element = React.cloneElement(element, {disabled: true});
      }

      if (!shouldSkip) {
        constructedForm = [
          constructedForm,
          <FormItem {...formItemLayout} key={fieldName} label={field['label']}>
            {getFieldDecorator(fieldName, {
              rules: field['rules'],
            })(element)}
          </FormItem>,
        ];
      }
    }

    return constructedForm;
  }

  render() {

    const actionButtons = {
      insert: (
        <FormItem {...tailFormItemLayout}>
          <Button key="btnSave" type="primary" htmlType="submit">
            Guardar
          </Button>
          <Divider key="divUpdDel" type="vertical" />
          <Button type="default" onClick={this.handleDefault}>
            Cancelar
          </Button>
        </FormItem>
      ),
      update: (
        <FormItem {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit" loading={this.state.submitting}>
            Actualizar
          </Button>
          <Divider key="divUpdDel" type="vertical" />
          <Button type="default" onClick={this.handleDefault}>
            Cancelar
          </Button>
        </FormItem>
      ),
      delete: (
        <FormItem {...tailFormItemLayout}>
          <Button type="danger" htmlType="submit" loading={this.state.submitting}>
            Eliminar
          </Button>
          <Divider key="divUpdDel" type="vertical" />
          <Button type="default" onClick={this.handleDefault}>
            Cancelar
          </Button>
        </FormItem>
      ),
    };

    let currentMode = this.props.currentMode;
    let constructedFields = this.constructFields(currentMode);
    let options = this.props.formConfig.options[currentMode];
    let title = options['title'];

    return (
      <Form onSubmit={this.handleSubmit}>
        <Spin spinning={this.state.loading}>
          <Card
            type="inner"
            title={title}
          >
          {constructedFields}
          {actionButtons[currentMode]}  
          </Card>
          
        </Spin>
      </Form>
    );
  }
}
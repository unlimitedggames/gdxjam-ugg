import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Table, Divider, Checkbox } from 'antd';
import moment from 'moment';
import reqwest from 'reqwest';

export class BaseTable extends Component {
  constructor(props) {
    super(props);
    if (this.props.fecthUrl === undefined) {
      this.state.data = this.props.data;
    }
    this.constructColumns();
  }

  static propTypes = {
    columns: PropTypes.array.isRequired,
    rowId: PropTypes.string.isRequired,
  };

  state = {
    filteredInfo: null,
    sortedInfo: null,
    data: [],
    pagination: { showSizeChanger: true, position: 'both' },
    loading: false,
  };

  componentWillReceiveProps(props) {
    const { refresh } = this.props;
    if (props.refresh !== refresh) {
      this.fetch();
    }
  }

  constructColumns() {
    let constructed = this.constructed || false;
    if (!constructed) {
      let columnsInfo = this.props.columns;
      for (var i = 0; i < columnsInfo.length; i++) {
        let currentColumnInfo = columnsInfo[i];

        let customRender = null;
        if(currentColumnInfo.sort === 'boolean'){
          customRender = (text, record) => {
            return <Checkbox checked={text} />;
          }
        }

        this.addColumn(
          currentColumnInfo.title,
          currentColumnInfo.name,
          currentColumnInfo.sort,
          currentColumnInfo.filter,
          customRender,
        );
      }

      let operationUpdate = this.props.updateHandler;
      let operationDelete = this.props.deleteHandler;
      let linksToDisplay = null;

      if(operationUpdate !== undefined || operationDelete !== undefined){
        this.addColumn('Operaciones', 'ops', null, false, (text, record) => {
          if (operationUpdate !== undefined) {
            linksToDisplay = <a key="opUpd" onClick={() => operationUpdate(record[this.props.rowId])}>Update</a>;
          }

          if (operationDelete !== undefined) {
            if (linksToDisplay == null) {
              linksToDisplay = <a key="opDel" onClick={() => operationDelete(record[this.props.rowId])}>">Delete</a>;
            } else {
              linksToDisplay =
                 [
                  linksToDisplay,
                  <Divider key="divUpdDel" type="vertical" />,
                  <a key="opDel" onClick={() => operationDelete(record[this.props.rowId])}>Delete</a>,
                ];
            }
          }

          return <span>{linksToDisplay}</span>;
        });
      }
      this.constructed = true;
    } else {
      this.updateSorting();
    }
  }

  addColumn(columnTitle, columnName, sortType, searchable, customRender) {
    let { sortedInfo } = this.state;
    let jsonColumn;
    sortedInfo = sortedInfo || {};
    this.columns = this.columns || [];

    jsonColumn = { title: columnTitle, dataIndex: columnName, key: columnName };

    if (sortType != null) {
      jsonColumn.sorter = (a, b) => {
        if (sortType === 'number') {
          return a[columnName] - b[columnName];
        } else if (sortType === 'string') {
          return a[columnName].localeCompare(b[columnName]);
        } else if (sortType === 'date') {
          return moment(a[columnName] || 0).unix() - moment(b[columnName] || 0).unix();
        } else if (sortType === 'ajax') {
          return true;
        } else if (sortType === 'boolean') {
          return a[columnName] - b[columnName];
        } else {
          return false;
        }
      };
      jsonColumn.sortOrder = sortedInfo.columnKey === columnName && sortedInfo.order;
    }

    if (customRender != null) {
      jsonColumn.render = customRender;
    }

    this.columns.push(jsonColumn);
  }

  handleChange = (pagination, filters, sorter) => {
    this.setState({
      filteredInfo: filters,
      sortedInfo: sorter,
    });
  };

  updateSorting() {
    let { sortedInfo } = this.state;
    sortedInfo = sortedInfo || {};
    for (var i = 0; i < this.columns.length; i++) {
      let columnFound = this.columns[i];
      columnFound.sortOrder = sortedInfo.columnKey === columnFound.key && sortedInfo.order;
    }
  }

  componentDidMount() {
    if (this.props.fecthUrl !== undefined) {
      this.fetch();
    }
  }

  fetch = (params = {}) => {
    const fetchUrl = this.props.fecthUrl;
    //console.log('fetching, params:', params);
    this.setState({ loading: true });

    reqwest({
      url: fetchUrl,
      method: 'get',
      data: {
        //results: 10,
        ...params,
      },
      type: 'json',
    }).then(data => {
      const pagination = { ...this.state.pagination };
      // Read total count from server
      pagination.total = data.totalCount;
      //pagination.total = 200;

      this.setState({
        loading: false,
        data: data,
        pagination,
      });
    });
  };

  render() {
    this.constructColumns();
    return (
      <div className="common-base-table">
        <Table
          columns={this.columns}
          dataSource={this.state.data}
          rowKey={record => record[this.props.rowId]}
          onChange={this.handleChange}
          loading={this.state.loading}
          pagination={this.state.pagination}
          bordered
        />
      </div>
    );
  }
}
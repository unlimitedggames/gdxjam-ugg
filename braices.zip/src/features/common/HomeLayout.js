import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Layout, Button, Row, Col, Icon} from 'antd';
import { Link } from 'react-router-dom';
import HomeMenu from './HomeMenu'

const { Content, Footer } = Layout;

export class HomeLayout extends Component {
  static propTypes = {
    children: PropTypes.node,
  };

  render() {
    
    return (
      <Layout style={{ minHeight: '100vh', background: '#fff' }}>
        <Layout>
          <HomeMenu />
          <Content style={{ margin: '16px 3vw 0' }}>
            <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
              {this.props.children}
            </div>
          </Content>
          <Footer className="home-footer">
            <Row>
              <Col lg={{span: 12}} className="margin-category">
                <div style={{color: "white", marginBottom: "8px"}}>Visitanos: </div>
                <Button type="primary" icon="facebook"/>
                <span> </span>
                <Button type="primary" icon="instagram"/>
                <span> </span>
                <Button type="primary" icon="twitter"/>
                <span> </span>
                <Button type="primary" icon="mail"/>
              </Col>
              <Col lg={{span: 4, offset: 8}} className="margin-category">
                <div className="home-footer-links">
                  <Link to="/dashboard">
                    <Icon type="message" />
                    <span> Contáctanos</span>
                  </Link>
                  <Link to="/dashboard">
                    <Icon type="team" />
                    <span> Acerca de</span>
                  </Link>
                </div>
              </Col>
            </Row>
            <Row>
              <p style={{color: "white", textAlign: "center"}}>Dev++ Todos los derechos reservados</p>
            </Row>
          </Footer >
        </Layout>
      </Layout>
    );
  }
}
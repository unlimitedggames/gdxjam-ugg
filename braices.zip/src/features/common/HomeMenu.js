import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import { Layout, Menu, Affix} from 'antd';
import { Link } from 'react-router-dom';
import { Logout } from './Logout'

const { Header } = Layout;

export class HomeMenu extends Component {
  static propTypes = {
    common: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.bool.isRequired,
    currentPath: PropTypes.string,
  };

  render() {
    const { isAuthenticated } = this.props
    const currentPath = this.props.currentPath;
    
    return (
      <div className="common-home-menu">
        <Affix>
          <Header style={{ background: '#fff', padding: '0 16px 0 16px' }}>
            <Link to="/home" >
            <div className="common-home-layout-logo" />
            </Link>
            <Menu
              theme="light"
              mode="horizontal"
              activeKey={currentPath}
              style={{ lineHeight: '64px' }}
              selectedKeys={ [ currentPath ] }
            >
              <Menu.Item key="/home/register">
                <Link to="/home/register" >
                  <b>Registrarse</b>
                </Link>
              </Menu.Item>
               { !isAuthenticated &&
                <Menu.Item key="/home/login">
                  <Link to="/home/login" >
                      <span>Ingresar</span>
                  </Link>
                </Menu.Item>
                
              }

              <Menu.Item key="3">Ayuda</Menu.Item>
              { isAuthenticated &&
                  <Logout onLogOutClick={() =>  this.props.actions.logOut() } divClass="logout-right" />
              }
            </Menu>
            
          </Header>
          </Affix>
      </div>
    );
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    common: state.common,
    isAuthenticated: state.common.isAuthenticated,
    currentPath: state.router.location.pathname,
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...actions }, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HomeMenu);
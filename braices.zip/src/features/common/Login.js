import React, { Component } from 'react';
import {Form, Checkbox, Button, Icon, Input} from 'antd';
import PropTypes from 'prop-types'

const FormItem = Form.Item;

export class Login extends Component {
  static propTypes = {
    onLoginClick: PropTypes.func.isRequired,
    errorMessage: PropTypes.string,
  };

handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const username = values.username;
        const password = values.password;
        const creds = { username: username, password: password }
        this.props.onLoginClick(creds);
      }
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <div className="common-login">
        <Form onSubmit={this.handleSubmit} className="login-form">
        <FormItem>
          {getFieldDecorator('userName', {
            rules: [{ required: true, message: this.props.messages.missingUser }],
          })(
            <Input prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.35)' }} />} placeholder={this.props.userPlaceholder} />
          )}
        </FormItem>
        <FormItem>
          {getFieldDecorator('password', {
            rules: [{ required: true, message: this.props.messages.missingPassword }],
          })(
            <Input prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.35)' }} />} type="password" placeholder={this.props.passwordPlaceholder} />
          )}
        </FormItem>
        <FormItem>
          
          {getFieldDecorator('remember', {
            valuePropName: 'checked',
            initialValue: true,
          })(
            <Checkbox>{this.props.texts.rememberMe}</Checkbox>
          )}
          <a className="login-form-forgot" href="">{this.props.texts.forgotPassword}</a>
          <Button type="primary" htmlType="submit" className="login-form-button">
            {this.props.texts.logIn}
          </Button>
          <a href="">{this.props.texts.register}</a>
        </FormItem>
      </Form>
      </div>
    );
  }
}
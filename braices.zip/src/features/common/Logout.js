import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { Badge, Avatar, Menu, Dropdown, Icon} from 'antd';

export class Logout extends Component {
  static propTypes = {

  }

  handleClick({key}, fn) {
    if(key === "close-session"){
      fn();
    }
  }

  render() {
    let fnLogOut = this.props.onLogOutClick;
    const menu = (
        <Menu onClick={key => this.handleClick(key, fnLogOut)}>
          <Menu.Item key="0">
            <Link to="/dashboard">
              <Icon type="user" />
              <span> Mi Perfil</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="1">
            <Link to="/dashboard">
              <Icon type="pie-chart" />
              <span> Administrador</span>
            </Link>
          </Menu.Item>
          <Menu.Divider />
          <Menu.Item key="close-session">
              <Icon type="logout" />
              <span> Cerrar Sesion</span>
          </Menu.Item>
        </Menu>
      );

    return (
      <Dropdown overlay={menu} trigger={['click']}>
      <div className={this.props.divClass}>
        <Badge count={1}><Avatar shape="square" icon="user" /></Badge>
      </div>
      </Dropdown>
    );
  }
}
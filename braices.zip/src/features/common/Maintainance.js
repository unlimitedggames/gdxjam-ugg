import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { BaseTable } from '../common/BaseTable';
import { Row, Col } from 'antd';
import { BaseForm } from '../common/BaseForm';
import { Form, Button, Affix } from 'antd';
import { PageHeader } from './PageHeader';

const FormWrap = Form.create()(BaseForm);

export class Maintainance extends Component {
  static propTypes = {
    operationUrl: PropTypes.string,
    fecthUrl: PropTypes.string,
    rowId: PropTypes.string.isRequired,
    columns: PropTypes.array,
    formConfig: PropTypes.object.isRequired,
  };

  state = {
    refreshTrigger: true,
    currentFormMode: 'insert',
    currentFormInfoId: '',
    currentTab: 'table',
  };

  triggerRefresh = () => {
    this.setState({ refreshTrigger: !this.state.refreshTrigger });
  };

  triggerUpdateForm = id => {
    console.log('Id de update: ', id);
    this.setState({ currentFormMode: 'update', currentFormInfoId: id, currentTab: 'form' });
  };

  triggerDeleteForm = id => {
    console.log('Id de delete: ', id);
    this.setState({ currentFormMode: 'delete', currentFormInfoId: id, currentTab: 'form' });
  };

  triggerInsertForm = id => {
    this.setState({ currentFormMode: 'insert', currentFormInfoId: '', currentTab: 'form' });
  };

  formCancelButtonHandler = () => {
    this.setState({ currentFormMode: 'insert', currentFormInfoId: '', currentTab: 'table' });
  };

  render() {
    const actionButton = (
      <Button icon="plus" type="primary" size="large" onClick={this.triggerInsertForm}>
        Agregar nuevo
      </Button>
    );
    console.log(this.props.tableWidget);
    const currentTab = this.state.currentTab;
    //{React.cloneElement(this.props.tableWidget, { rowId: this.props.rowId })}
    return (
      <div>
        <Affix>
          <PageHeader
            header={this.props.header}
            showBreadcrumb="true"
            actionButton={actionButton}
          />
        </Affix>
        <div
          style={{
            background: '#fff',
            padding: '16px',
            marginLeft: '16px',
            marginRight: '16px',
            minHeight: '75vh',
          }}
        >
          {currentTab === 'table' && (
            <Row>
              {this.props.tableWidget === undefined && (
                <BaseTable
                  columns={this.props.columns}
                  rowId={this.props.rowId}
                  fecthUrl={this.props.fecthUrl}
                  refresh={this.state.refreshTrigger}
                  updateHandler={this.triggerUpdateForm}
                  deleteHandler={this.triggerDeleteForm}
                />
              )}
              {this.props.tableWidget !== undefined &&
                React.cloneElement(this.props.tableWidget, {
                  rowId: this.props.rowId,
                  fecthUrl: this.props.fecthUrl,
                  refresh: this.state.refreshTrigger,
                  updateHandler: this.triggerUpdateForm,
                  deleteHandler: this.triggerDeleteForm
                })}
            </Row>
          )}

          {currentTab === 'form' && (
            <Row>
              <FormWrap
                currentMode={this.state.currentFormMode}
                currentId={this.state.currentFormInfoId}
                refreshHandler={this.triggerRefresh}
                operationUrl={this.props.operationUrl}
                formConfig={this.props.formConfig}
                cancelHandler={this.formCancelButtonHandler}
              />
            </Row>
          )}
        </div>
      </div>
    );
  }
}
import React, { Component } from 'react';
import { Breadcrumb } from 'antd';

export class PageHeader extends Component {
  static propTypes = {

  };

  render() {
    const { showBreadcrumb, actionButton } = this.props;
    return (
      <div className="common-page-header">
        {
          showBreadcrumb && 
          <Breadcrumb>
          <Breadcrumb.Item>User</Breadcrumb.Item>
          <Breadcrumb.Item>Bill</Breadcrumb.Item>
        </Breadcrumb>
        }
        <div className="actionBtn">
        {
          (actionButton !== "undefined") && actionButton
        }
        </div>
        <h1>{this.props.header}</h1>
        <div style={{ clear: "both" }} ></div>
      </div>
    );
  }
}
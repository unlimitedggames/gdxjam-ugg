import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import { Layout, Menu, Icon, Divider } from 'antd';
import { Link } from 'react-router-dom';

const { Sider } = Layout;
const SubMenu = Menu.SubMenu;

const collapsableMenus = [ '/admin', '/catalogs' ]

export class SideMenu extends Component {
  static propTypes = {
    home: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
    currentPath: PropTypes.string,
  };

  state = {
    collapsed: false,
  };

  onCollapse = collapsed => {
    console.log(collapsed);
    this.setState({ collapsed });
  };

  render() {
    const currentPath = this.props.currentPath;
    let openMenuKeys = [];
    for(let i = 0; i < collapsableMenus.length; i++){
      let menuString = collapsableMenus[i];
      if(currentPath.includes(menuString)){
          openMenuKeys.push(menuString);
          break;
      }
    }
    //console.log(currentPath, openMenuKeys);

    return (
      <Sider 
        breakpoint="lg"
        collapsedWidth="0"
        collapsed={this.state.collapsed}
        onCollapse={this.onCollapse}
        className="whitebg"
      >
        <Menu theme="light" mode="inline"
          activeKey={currentPath}
          selectedKeys={ [ currentPath ] }
          defaultOpenKeys={openMenuKeys}
          >
          <Menu.Item key="/dashboard">
            <Link to="/dashboard">
              <Icon type="dashboard" />
              <span>Inicio</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/persons">
            <Link to="/persons">
              <Icon type="team" />
              <span>Personas</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/estates">
            <Link to="/estates">
              <Icon type="home" />
              <span>Mis Propiedades</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/search">
            <Link to="/search">
              <Icon type="search" />
              <span>Búsquedas</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/reports">
            <Link to="/reports">
              <Icon type="table" />
              <span>Reportes</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/allies">
            <Link to="/allies">
              <Icon type="trophy" />
              <span>Alianzas</span>
            </Link>
          </Menu.Item>
          <Menu.Item key="/matches">
            <Link to="/matches">
              <Icon type="exclamation" />
              <span>Encontrados</span>
            </Link>
          </Menu.Item>
          <Menu.Item>
          <Divider type="horizontal" />
          </Menu.Item>
          <SubMenu
            key="/admin"
            title={
              <span>
                <Icon type="user" />
                <span>Admin</span>
              </span>
            }
          >
            <Menu.Item key="/admin/roles">
              <Link to="/admin/roles">Roles</Link>
            </Menu.Item>
          </SubMenu>
          <SubMenu
            key="/catalogs"
            title={
              <span>
                <Icon type="user" />
                <span>Catalogos</span>
              </span>
            }
          >
            <Menu.Item key="/catalogs/tableCache">
              <Link to="/catalogs/tableCache">Tablas</Link>
            </Menu.Item>
          </SubMenu>
        </Menu>
      </Sider>
    );
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    home: state.home,
    currentPath: state.router.location.pathname,
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...actions }, dispatch),
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(SideMenu);
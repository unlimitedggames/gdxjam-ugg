import {
  COMMON_LOG_OUT_BEGIN,
  COMMON_LOG_OUT_SUCCESS,
  COMMON_LOG_OUT_FAILURE,
} from './constants';

function requestLogout() {
  return {
    type: COMMON_LOG_OUT_BEGIN,
    isFetching: true,
    isAuthenticated: true
  }
}

function receiveLogout() {
  return {
    type: COMMON_LOG_OUT_SUCCESS,
    isFetching: false,
    isAuthenticated: false
  }
}

// Rekit uses redux-thunk for async actions by default: https://github.com/gaearon/redux-thunk
// If you prefer redux-saga, you can use rekit-plugin-redux-saga: https://github.com/supnate/rekit-plugin-redux-saga
export function logOut(args = {}) {
  return (dispatch) => { 
    console.log("logout");
    dispatch(requestLogout());
    localStorage.removeItem('id_token')
    localStorage.removeItem('access_token')
    dispatch(receiveLogout());
  };
}

export function reducer(state, action) {
  switch (action.type) {
    case COMMON_LOG_OUT_BEGIN:
      // Just after a request is sent
      return {
        ...state,
        logOutPending: true,
        logOutError: null,
      };

    case COMMON_LOG_OUT_SUCCESS:
      // The request is success
      return {
        ...state,
        logOutPending: false,
        isAuthenticated: false,
        logOutError: null,
      };

    case COMMON_LOG_OUT_FAILURE:
      // The request is failed
      return {
        ...state,
        logOutPending: false,
        isAuthenticated: false,
        logOutError: action.data.error,
      };

    default:
      return state;
  }
}

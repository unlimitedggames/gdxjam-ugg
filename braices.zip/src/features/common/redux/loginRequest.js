import {
  COMMON_LOGIN_REQUEST_BEGIN,
  COMMON_LOGIN_REQUEST_SUCCESS,
  COMMON_LOGIN_REQUEST_FAILURE,
  COMMON_LOGIN_REQUEST_DISMISS_ERROR,
} from './constants';

function requestLogin(creds) {
  return {
    type: COMMON_LOGIN_REQUEST_BEGIN,
    isFetching: true,
    isAuthenticated: false,
    creds
  }
}

function receiveLogin(user) {
  return {
    type: COMMON_LOGIN_REQUEST_SUCCESS,
    isFetching: false,
    isAuthenticated: true,
    id_token: user.id_token
  }
}

function loginError(message) {
  return {
    type: COMMON_LOGIN_REQUEST_FAILURE,
    isFetching: false,
    isAuthenticated: false,
    message
  }
}

// Rekit uses redux-thunk for async actions by default: https://github.com/gaearon/redux-thunk
// If you prefer redux-saga, you can use rekit-plugin-redux-saga: https://github.com/supnate/rekit-plugin-redux-saga
export function loginRequest(creds) {
  let config = {
    method: 'POST',
    headers: { 'Content-Type':'application/x-www-form-urlencoded' },
    body: `username=${creds.username}&password=${creds.password}`
  }
  return (dispatch) => {
    // We dispatch requestLogin to kickoff the call to the API
    dispatch(requestLogin(creds));

    let user = { id_token: 'ABCDEF' };
    localStorage.setItem('id_token', user.id_token);
    dispatch(receiveLogin(user));

    /*return fetch('http://localhost:3001/sessions/create', config)
      .then(response => response.json().then(user => ({ user, response })),
          error => console.log('An error occurred.', error) 
      ).then(({ user, response }) =>  {
        if (!response.ok) {
          // If there was a problem, we want to
          // dispatch the error condition
          dispatch(loginError(user.message))
          return Promise.reject(user)
        }
        else {
          // If login was successful, set the token in local storage
          localStorage.setItem('id_token', user.id_token)
          
          // Dispatch the success action
          dispatch(receiveLogin(user))
        }
      })*/
  };
}

// Async action saves request error by default, this method is used to dismiss the error info.
// If you don't want errors to be saved in Redux store, just ignore this method.
export function dismissLoginRequestError() {
  return {
    type: COMMON_LOGIN_REQUEST_DISMISS_ERROR,
  };
}

export function reducer(state, action) {
  switch (action.type) {
    case COMMON_LOGIN_REQUEST_BEGIN:
      // Just after a request is sent
      return {
        ...state,
        isFetching: true,
        isAuthenticated: false,
        user: action.creds
      };

    case COMMON_LOGIN_REQUEST_SUCCESS:
      // The request is success
      return {
        ...state,
        isFetching: false,
        isAuthenticated: true,
        errorMessage: ''
      };

    case COMMON_LOGIN_REQUEST_FAILURE:
      // The request is failed
      return {
        ...state,
        isFetching: false,
        isAuthenticated: false,
        errorMessage: action.message
      };

    default:
      return state;
  }
}
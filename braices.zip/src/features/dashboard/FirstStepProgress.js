import React, { Component } from 'react';
import { Card, Icon, Row, Col, Progress } from 'antd';

export default class FirstStepProgress extends Component {
  static propTypes = {

  };

  render() {
    return (
      <div className="dashboard-first-step-progress">
        <Progress type="circle" percent={75} width={80} />
        <span style={{ display: "block", marginTop: "5px" }}>Perfil</span>
      </div>
    );
  }
}
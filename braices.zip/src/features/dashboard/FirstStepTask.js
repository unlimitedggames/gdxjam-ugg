import React, { Component } from 'react';
import { Skeleton, Switch, Card, Icon, Avatar, Col } from 'antd';

export default class FirstStepTask extends Component {
  static propTypes = {

  };

  render() {
    return (
        <div className="first-step-task">
          <Icon type={this.props.iconType} className="icon" />
          <span>{this.props.description}</span>
        </div>
    );
  }
}
import React, { Component } from 'react';
import { Card, Icon, Row, Col, Progress } from 'antd';
import { FirstStepTask, FirstStepProgress } from './';

const { Meta } = Card;

export default class FirstSteps extends Component {
  static propTypes = {

  };

  state = {
    loading: false,
  }

  render() {
    const { loading } = this.state;
    return (
      <div className="dashboard-first-steps">
        <Card loading={loading} title="Primeros pasos">
          <Row gutter={8} type="flex" align="middle">
          <Col>
            <FirstStepProgress />
          </Col>
          <Col>
          <FirstStepTask description="Foto" iconType="camera" />
          </Col>
          <Col>
          <FirstStepTask description="Contacto" iconType="user" />
          </Col>
          </Row>
        </Card>
      </div>
    );
  }
}
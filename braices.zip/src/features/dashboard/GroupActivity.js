import React, { Component } from 'react';
import { Skeleton, Switch, Card, Icon, Avatar, Select, Button } from 'antd';
import { GroupActivityEntry } from './';

const Option = Select.Option;

const children = [];
children.push(<Option key={1}>Ahuachapán</Option>);
children.push(<Option key={5}>La Libertad</Option>);
children.push(<Option key={6}>San Salvador</Option>);

function handleChange(value) {
  console.log(`selected ${value}`);
}

export default class GroupActivity extends Component {
  static propTypes = {

  };

  render() {
    const buttons = 
                <div>
                <Button type="primary" size="large" shape="circle" icon="share-alt" />
                <span> </span>
                <Button type="primary" size="large" shape="circle" icon="mail" />
                <span> </span>
                <Button type="primary" size="large" shape="circle" icon="team" />
                </div>
    return (
      <div className="dashboard-group-activity">
          <Card style={{ marginBottom: "5px" }} className="">
            <div>
              <b style={{ marginRight: "16px" }}>Actividad en el grupo: </b>
               <Select
                mode="multiple"
                style={{ width: '80%' }}
                placeholder="Please select"
                defaultValue={['La Libertad']}
                onChange={handleChange}
              >
                {children}
              </Select>
            </div>
          </Card>
          <GroupActivityEntry 
            showTitle={true}
            title="Usuario actualizo el item"
            avatarUrl="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png"
            time="Hace 3 minutos" 
            photos={[ 
              'https://www.elsv.info/wp-content/uploads/2017/04/imagen-de-una-casa.jpg',
              'https://3.bp.blogspot.com/_VBkvBscmZTo/SZQ9vlrWiSI/AAAAAAAAAEE/5_GDU6YzofE/s500/C.+Santa+Cecilia.JPG'
              ]}
            itemProperties={
              { Tipo: "Casa en venta",
                Ubicación: "Antiguo Cuscatlán, La Libertad",
                Precio: "$100000",
                Niveles: 2,
                Habitaciones: 2,
                Baños: 2,
                Area: "256 mts2"
             }}
             buttons={buttons}
          />
          <GroupActivityEntry
            showTitle={false}
            title="Usuario 2 actualizo el item"
            avatarUrl="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png"
            time="Hace 3 minutos"
            itemProperties={
              { Tipo: "Casa en alquiler",
                Ubicación: "Santa Tecla, La Libertad",
                Precio: "$120000",
                Area: "300 mts2",
                Relieve: "Plano"
             }}
             buttons={buttons}
          />
      </div>
    );
  }
}

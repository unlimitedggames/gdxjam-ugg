import React, { Component } from 'react';
import { Button, Icon, Card, Avatar, Col, Row, Carousel } from 'antd';

const { Meta } = Card;

function GroupActivityEntryItemRepeat(props) {
  let data = props.data;
  let items = [];
  if (data !== undefined) {
    let count = Object.keys(data).length;
    let current = 0;
    for (var key in data) {
      var attrName = key;
      var attrValue = data[key];

      if (current == count - 1) {
        items.push(
          <Row key={key}>
            <Col lg={{ span: 18 }}>
              <b>{attrName}:</b> {attrValue}
            </Col>
            <Col lg={{ span: 6 }} style={{ marginTop: '8px' }}>
              <div style={{ width: '100%', textAlign: 'right' }}>
                {props.buttons}
              </div>
            </Col>
          </Row>,
        );
      } else {
        items.push(
          <Row key={key}>
            <b>{attrName}:</b> {attrValue}
          </Row>,
        );
      }

      current++;
    }
  }
  return <div>{items}</div>;
}

function ImageCarousel(props) {
  let photos = props.photos;
  let items = [];
  if (photos !== undefined) {
    for(var i = 0; i < photos.length; i++){
      let photo = photos[i];
      items.push(
                  <div key={i}>
                    <img alt={i} src={photo} className="carousel-img" />
                  </div>
      );
    }
  }else{
    items.push(
                  <div key='last'>
                  </div>
      );
  }
  return <Carousel key='imgCarousel' effect="fade" autoplay>{items}</Carousel>;
}

export default class GroupActivityEntry extends Component {
  static propTypes = {};

  state = {
    loading: false,
  };

  render() {
    const { loading } = this.state;
    const { showTitle } = this.props;
    const photos = this.props.photos;
    return (
      <div className="dashboard-group-activity-entry">
        { showTitle &&
        <Card loading={loading}>
          <Meta
            avatar={<Avatar src={this.props.avatarUrl} />}
            title={this.props.title}
            description={this.props.time}
          />
        </Card>
        }
        <Card loading={loading}>
          <Row gutter={{ lg: 16 }}>
            
              <Col lg={{ span: 6 }}>
              <div className="group-entry-carousel">
                <ImageCarousel photos={photos} />
              </div>
            </Col>
            
            <Col lg={{ span: 18 }}>
              <div style={{ marginTop: '8px' }} />
              <GroupActivityEntryItemRepeat 
                  data={this.props.itemProperties}
                  buttons={this.props.buttons}
                   />
            </Col>
          </Row>
        </Card>
      </div>
    );
  }
}
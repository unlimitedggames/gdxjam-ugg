import {
  DefaultPage,
} from './';

import {
  AdminLayout
} from '../common/AdminLayout';

export default {
  path: '/dashboard',
  name: 'Dashboard',
  component: AdminLayout,
  childRoutes: [
    { path: 'default-page',
      name: 'Default page',
      component: DefaultPage,
      isIndex: true,
    },
  ],
};
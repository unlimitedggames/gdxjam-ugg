import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import { EstateTable } from './';
import { Maintainance } from '../common/Maintainance'
import { Input } from 'antd';

const columns = [
 
];

const commonFields = [
  {
    name: 'id',
    label: 'Id',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el id',
      },
    ],
  },
  {
    name: 'tipo',
    label: 'Tipo de Propiedad',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el tipo de propiedad',
      },
    ],
  },
  {
    name: 'ubicacion',
    label: 'Ubicacion',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese la ubicacion',
      },
    ],
  },
  {
    name: 'precio',
    label: 'Precio',
    element: <Input />,
    rules: [
      {
        required: true,
        message: 'Ingrese el precio',
      },
    ],
  },
];

const formConfig = {
  options: {
    insert: {
      title: 'Agregar propiedad',
      skipFields: ['id'],
    },
    update: {
      title: 'Editar propiedad',
      disabledFields: ['id'],
    },
    delete: {
      title: 'Eliminar propiedad',
    },
  },
  fields: {
    insert: commonFields,
    update: commonFields,
    delete: commonFields,
  },
};

export class DefaultPage extends Component {
  static propTypes = {
    estates: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
  };

  render() {
    console.log("key", process.env.REACT_APP_SECRET_CODE);
    const tableWidget = <EstateTable header="Mis Propiedades" />
    return (
      <div className="estates-default-page">
        <Maintainance
            header="Mis Propiedades" 
            tableWidget={tableWidget} 
            rowId="id" 
            formConfig={formConfig}
        />
      </div>
    );
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    estates: state.estates,
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...actions }, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultPage);
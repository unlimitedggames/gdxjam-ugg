import React, { Component } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import reqwest from 'reqwest';
import { Row, Button, Spin, Pagination } from 'antd';
import { GroupActivityEntry } from '../dashboard';

function EntityTableRows(props) {
  let dataSource = props.dataSource;
  let items = [];
  let rowKey = props.rowKey;
  let pageSize = props.pageSize;
  let currentPage = props.current;
  let initRow = (pageSize * (currentPage - 1));
  let endRow = initRow + pageSize;
  if (dataSource !== undefined) {
    for (var i = initRow; i < endRow; i++) {
      console.log("initRow: " + initRow, "endRow: " + endRow, "i: " + i)
      if(i >= dataSource.length){
        break;
      }

      let dataObject = dataSource[i];
      let rowId = dataObject[rowKey];

      let operationUpdate = props.updateHandler;
      let operationDelete = props.deleteHandler;
      let linksToDisplay = null;
      let buttons = null;

      if (operationUpdate !== undefined || operationDelete !== undefined) {
        if (operationUpdate !== undefined) {
          linksToDisplay = (
            <Button key="opUpd" onClick={() => operationUpdate(rowId)} type="primary" size="large" shape="circle" icon="edit" />
          );
        }

        if (operationDelete !== undefined) {
          if (linksToDisplay == null) {
            linksToDisplay = <Button key="opDel" onClick={() => operationDelete(rowId)} type="danger" size="large" shape="circle" icon="delete" />;
          } else {
            linksToDisplay = [
              linksToDisplay,
              <span key="divUpdDel"> </span>,
              <Button key="opDel" onClick={() => operationDelete(rowId)} type="danger" size="large" shape="circle" icon="delete" />,
            ];
          }
        }

        buttons = <span>{linksToDisplay}</span>;
      }

      items.push(
        <Row key={dataObject[rowKey]}>
          {React.cloneElement(<GroupActivityEntry />, { ...dataObject, buttons })}
        </Row>,
      );
    }
  }
  return items;
}

const data = [
  {
    id: 1,
    showTitle: false,
    title: 'Usuario actualizo el item',
    avatarUrl: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
    time: 'Hace 3 minutos',
    photos: [
      'https://www.elsv.info/wp-content/uploads/2017/04/imagen-de-una-casa.jpg',
      'https://3.bp.blogspot.com/_VBkvBscmZTo/SZQ9vlrWiSI/AAAAAAAAAEE/5_GDU6YzofE/s500/C.+Santa+Cecilia.JPG',
    ],
    itemProperties: {
      Tipo: 'Casa en venta',
      Ubicación: 'Antiguo Cuscatlán, La Libertad',
      Precio: '$100000',
      Niveles: 2,
      Habitaciones: 2,
      Baños: 2,
      Area: '256 mts2',
    },
  },
];

export default class EstateTable extends Component {
  constructor(props) {
    super(props);
    if (this.props.fecthUrl === undefined) {
      this.state.data = this.props.data;
      if (this.state.data === undefined) {
        this.state.data = data;
      }
    }
  }

  static propTypes = {};

  static propTypes = {
    rowId: PropTypes.string,
  };

  state = {
    data: [],
    pagination: { showSizeChanger: true, position: 'both', pageSize: 10, current: 1 },
    loading: false,
  };

  componentWillReceiveProps(props) {
    const { refresh } = this.props;
    if (props.refresh !== refresh) {
      this.fetch();
    }
  }

  componentDidMount() {
    if (this.props.fecthUrl !== undefined) {
      this.fetch();
    }
  }

  fetch = (params = {}) => {
    const fetchUrl = this.props.fecthUrl;
    this.setState({ loading: true });

    reqwest({
      url: fetchUrl,
      method: 'get',
      data: {
        //results: 10,
        ...params,
      },
      type: 'json',
    }).then(data => {
      const pagination = { ...this.state.pagination };
      // Read total count from server
      pagination.total = data.totalCount;
      //pagination.total = 200;

      this.setState({
        loading: false,
        data: data,
        pagination,
      });
    });
  };

  onShowSizeChange(current, pageSize) {
    console.log(current, pageSize);
    this.setState({ pagination: { 'current' : current, 'pageSize': pageSize }});
    console.log(this.state.pagination.current, this.state.pagination.pageSize);
  }

  render() {
    return (
      <div className="estates-estate-table">
        <Spin spinning={this.state.loading}>
        <Pagination showSizeChanger {...this.state.pagination} onShowSizeChange={(current, pageSize) => { this.onShowSizeChange(current, pageSize); }} total={this.state.data.length} />
        <EntityTableRows
          dataSource={this.state.data}
          rowKey={this.props.rowId}
          updateHandler={this.props.updateHandler}
          deleteHandler={this.props.deleteHandler}
          current={this.state.pagination.current}
          pageSize={this.state.pagination.pageSize}
        />
        <Pagination showSizeChanger {...this.state.pagination} onShowSizeChange={(current, pageSize) => { this.onShowSizeChange(current, pageSize); }} total={this.state.data.length} style={{ marginTop: "5px" }}/>
        </Spin>
      </div>
    );
  }
}
import React, { Component } from 'react';
import { Carousel, Button, Row, Col, Card, Icon } from 'antd';

const { Meta } = Card;

export default class HomePage extends Component {
  static propTypes = {};

  render() {
    return (
      <div className="home-home-page">
        <Row>
          <Carousel autoplay>
            <div>
              <div className="vh-center">
                <div>
                  <h3>Este seria un mensaje</h3>
                  <Button>Este el boton</Button>
                </div>
              </div>
            </div>
            <div>
              <div className="vh-center">
                <div>
                  <h3>Este seria el segundo mensaje</h3>
                  <Button>Este el boton</Button>
                </div>
              </div>
            </div>
            <div>
              <div className="vh-center">
                <div>
                  <h3>Este seria el tercer mensaje</h3>
                  <Button>Este el boton</Button>
                </div>
              </div>
            </div>
          </Carousel>
        </Row>
        <Row gutter={{ lg: 16 }}>
          <Col lg={{ span: 8 }} className="margin-category">
            <Card cover={<Icon type="user" className="card-icon" />}>
              <Meta title="Clientes" description="Opiniones y Calificaciones" />
            </Card>
          </Col>
          <Col lg={{ span: 8 }} className="margin-category">
            <Card cover={<Icon type="usergroup-add" className="card-icon" />}>
              <Meta title="Comunidad" description="Profesionales" />
            </Card>
          </Col>
          <Col lg={{ span: 8 }} className="margin-category">
            <Card cover={<Icon type="line-chart" className="card-icon" />}>
              <Meta title="Ingresos" description="Colega" />
            </Card>
          </Col>
        </Row>
        <Row gutter={{ lg: 16 }}>
          <Col lg={{ span: 12 }} className="margin-category">
            <div style={{textAlign: "right"}}>
              <h1>Todo a la mano</h1>
              <p>Llevar agenda y todo</p>
              <Button>Este es el boton</Button>
            </div>
          </Col>
          <Col lg={{ span: 12 }} className="margin-category">
            <div>
              <img alt="example" style={{width: "100%"}} src="https://img.purch.com/rc/816x500/aHR0cHM6Ly93d3cuYnVzaW5lc3NuZXdzZGFpbHkuY29tL2ltYWdlcy9pLzAwMC8wMDcvODc0L29yaWdpbmFsL2ZyZWUtYnVzaW5lc3MtcGxhbi10ZW1wbGF0ZXMuanBn" />
            </div>
          </Col>
        </Row>
      </div>
    );
  }
}
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actions from './redux/actions';
import * as commonActions from '../common/redux/actions';
import { Redirect } from 'react-router-dom';
import { Login } from '../common/Login'
import {Card, Form} from 'antd';

const LoginFormWrap = Form.create()(Login);

export class LoginForm extends Component {
  static propTypes = {
    actions: PropTypes.object.isRequired,
    common: PropTypes.object.isRequired,
    isAuthenticated: PropTypes.bool.isRequired
  };

  render() {
    let { isAuthenticated } = this.props;
    if(isAuthenticated){
      return(<Redirect to="/"/>)
    }else{
      return (
        <div className="home-login-form">
        <Card
              type="inner"
              title={"Iniciar Sesión"}
          >
          <LoginFormWrap userPlaceholder="Usuario" passwordPlaceholder="Contraseña" 
            onLoginClick={ creds => this.props.actions.loginRequest(creds) }
            messages={{ missingUser: "Ingrese su nombre de usuario", missingPassword: "Ingrese su contraseña" }}
            texts={{ rememberMe: "Recordarme", 
            forgotPassword: "Olvide mi contraseña", 
            register: "o Regístrese ahora!",
            logIn: "Ingresar" }} />
          </Card>
        </div>
      );
    }
    
  }
}

/* istanbul ignore next */
function mapStateToProps(state) {
  return {
    common: state.common,
    isAuthenticated: state.common.isAuthenticated
  };
}

/* istanbul ignore next */
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...commonActions, ...actions }, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LoginForm);


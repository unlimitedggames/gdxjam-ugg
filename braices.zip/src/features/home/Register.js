import React, { Component } from 'react';
import { Button, Row, Divider, Card } from 'antd';
import { Link } from 'react-router-dom';

export default class Register extends Component {
  static propTypes = {

  };

  render() {
    return (
      <div className="home-register">
        <Card
              type="inner"
        >
        <Row>
         <Button icon="google" size="large" type="danger" className="home-register-btn btn-google">Registrate con Google</Button>
         <Button icon="facebook" size="large" type="primary" className="home-register-btn">Registrate con Facebook</Button>
         <Button icon="mail" size="large" className="home-register-btn">Registrate con tu correo electrónico</Button>
         </Row>
         <Divider />
         <Row style={{ textAlign: "center" }}>
          <p>¿Tienes una cuenta? <Link to="/login"><span>Ingresa</span></Link></p>
         </Row>
         </Card>
      </div>
    );
  }
}
import React, { Component } from 'react';
import { Register } from './';

export default class RegisterPage extends Component {
  static propTypes = {

  };

  render() {
    return (
      <div className="home-register-page">
        <h1 style={{ textAlign: "center" }}>Crea tu cuenta y disfruta de 30 días GRATIS</h1>
        <Register />
        
      </div>
    );
  }
}

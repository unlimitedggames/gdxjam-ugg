import {
  HomePage,
  LoginForm,
  RegisterPage,
} from './';

import {
  HomeLayout
} from '../common/HomeLayout';


export default {
  path: '/home',
  name: 'Home',
  component: HomeLayout,
  childRoutes: [
    { path: 'index',
      name: 'Default page',
      component: HomePage,
      isIndex: true,
    },
    { path: '/login', name: 'Login form', component: LoginForm },
    { path: 'register', name: 'Register page', component: RegisterPage },
  ],
};
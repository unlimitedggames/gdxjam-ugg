import React from 'react';
import { shallow } from 'enzyme';
import { RolePage } from '../../../src/features/admin';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<RolePage />);
  expect(renderedComponent.find('.admin-role-page').length).toBe(1);
});

import React from 'react';
import { shallow } from 'enzyme';
import { DefaultPage } from '../../../src/features/catalogs/DefaultPage';

describe('catalogs/DefaultPage', () => {
  it('renders node with correct class name', () => {
    const props = {
      catalogs: {},
      actions: {},
    };
    const renderedComponent = shallow(
      <DefaultPage {...props} />
    );

    expect(
      renderedComponent.find('.catalogs-default-page').length
    ).toBe(1);
  });
});

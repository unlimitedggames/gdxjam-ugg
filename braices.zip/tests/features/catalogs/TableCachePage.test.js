import React from 'react';
import { shallow } from 'enzyme';
import { TableCachePage } from '../../../src/features/catalogs';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<TableCachePage />);
  expect(renderedComponent.find('.catalogs-table-cache-page').length).toBe(1);
});

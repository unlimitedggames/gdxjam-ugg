import React from 'react';
import { shallow } from 'enzyme';
import { AdminMenu } from '../../../src/features/common';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<AdminMenu />);
  expect(renderedComponent.find('.common-admin-menu').length).toBe(1);
});

import React from 'react';
import { shallow } from 'enzyme';
import { BaseForm } from '../../../src/features/common';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<BaseForm />);
  expect(renderedComponent.find('.common-base-form').length).toBe(1);
});

import React from 'react';
import { shallow } from 'enzyme';
import { BaseTable } from '../../../src/features/common';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<BaseTable />);
  expect(renderedComponent.find('.common-base-table').length).toBe(1);
});

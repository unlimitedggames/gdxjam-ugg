import React from 'react';
import { shallow } from 'enzyme';
import { HomeMenu } from '../../../src/features/common';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<HomeMenu />);
  expect(renderedComponent.find('.common-home-menu').length).toBe(1);
});

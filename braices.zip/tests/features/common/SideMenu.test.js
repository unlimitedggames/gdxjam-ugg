import React from 'react';
import { shallow } from 'enzyme';
import { SideMenu } from '../../../src/features/common';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<SideMenu />);
  expect(renderedComponent.find('.common-side-menu').length).toBe(1);
});

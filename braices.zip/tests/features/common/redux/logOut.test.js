import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import nock from 'nock';

import {
  COMMON_LOG_OUT_BEGIN,
  COMMON_LOG_OUT_SUCCESS,
  COMMON_LOG_OUT_FAILURE,
  COMMON_LOG_OUT_DISMISS_ERROR,
} from '../../../../src/features/common/redux/constants';

import {
  logOut,
  dismissLogOutError,
  reducer,
} from '../../../../src/features/common/redux/logOut';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

describe('common/redux/logOut', () => {
  afterEach(() => {
    nock.cleanAll();
  });

  it('dispatches success action when logOut succeeds', () => {
    const store = mockStore({});

    return store.dispatch(logOut())
      .then(() => {
        const actions = store.getActions();
        expect(actions[0]).toHaveProperty('type', COMMON_LOG_OUT_BEGIN);
        expect(actions[1]).toHaveProperty('type', COMMON_LOG_OUT_SUCCESS);
      });
  });

  it('dispatches failure action when logOut fails', () => {
    const store = mockStore({});

    return store.dispatch(logOut({ error: true }))
      .catch(() => {
        const actions = store.getActions();
        expect(actions[0]).toHaveProperty('type', COMMON_LOG_OUT_BEGIN);
        expect(actions[1]).toHaveProperty('type', COMMON_LOG_OUT_FAILURE);
        expect(actions[1]).toHaveProperty('data.error', expect.anything());
      });
  });

  it('returns correct action by dismissLogOutError', () => {
    const expectedAction = {
      type: COMMON_LOG_OUT_DISMISS_ERROR,
    };
    expect(dismissLogOutError()).toEqual(expectedAction);
  });

  it('handles action type COMMON_LOG_OUT_BEGIN correctly', () => {
    const prevState = { logOutPending: false };
    const state = reducer(
      prevState,
      { type: COMMON_LOG_OUT_BEGIN }
    );
    expect(state).not.toBe(prevState); // should be immutable
    expect(state.logOutPending).toBe(true);
  });

  it('handles action type COMMON_LOG_OUT_SUCCESS correctly', () => {
    const prevState = { logOutPending: true };
    const state = reducer(
      prevState,
      { type: COMMON_LOG_OUT_SUCCESS, data: {} }
    );
    expect(state).not.toBe(prevState); // should be immutable
    expect(state.logOutPending).toBe(false);
  });

  it('handles action type COMMON_LOG_OUT_FAILURE correctly', () => {
    const prevState = { logOutPending: true };
    const state = reducer(
      prevState,
      { type: COMMON_LOG_OUT_FAILURE, data: { error: new Error('some error') } }
    );
    expect(state).not.toBe(prevState); // should be immutable
    expect(state.logOutPending).toBe(false);
    expect(state.logOutError).toEqual(expect.anything());
  });

  it('handles action type COMMON_LOG_OUT_DISMISS_ERROR correctly', () => {
    const prevState = { logOutError: new Error('some error') };
    const state = reducer(
      prevState,
      { type: COMMON_LOG_OUT_DISMISS_ERROR }
    );
    expect(state).not.toBe(prevState); // should be immutable
    expect(state.logOutError).toBe(null);
  });
});


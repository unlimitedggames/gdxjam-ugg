import {
  COMMON_LOGIN_REQUEST,
} from '../../../../src/features/common/redux/constants';

import {
  loginRequest,
  reducer,
} from '../../../../src/features/common/redux/loginRequest';

describe('common/redux/loginRequest', () => {
  it('returns correct action by loginRequest', () => {
    expect(loginRequest()).toHaveProperty('type', COMMON_LOGIN_REQUEST);
  });

  it('handles action type COMMON_LOGIN_REQUEST correctly', () => {
    const prevState = {};
    const state = reducer(
      prevState,
      { type: COMMON_LOGIN_REQUEST }
    );
    // Should be immutable
    expect(state).not.toBe(prevState);

    // TODO: use real case expected value instead of {}.
    const expectedState = {};
    expect(state).toEqual(expectedState);
  });
});

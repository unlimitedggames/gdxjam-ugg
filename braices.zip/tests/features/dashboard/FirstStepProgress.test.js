import React from 'react';
import { shallow } from 'enzyme';
import { FirstStepProgress } from '../../../src/features/dashboard';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<FirstStepProgress />);
  expect(renderedComponent.find('.dashboard-first-step-progress').length).toBe(1);
});

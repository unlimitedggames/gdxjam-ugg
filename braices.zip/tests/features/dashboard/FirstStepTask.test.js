import React from 'react';
import { shallow } from 'enzyme';
import { FirstStepTask } from '../../../src/features/dashboard';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<FirstStepTask />);
  expect(renderedComponent.find('.dashboard-first-step-task').length).toBe(1);
});

import React from 'react';
import { shallow } from 'enzyme';
import { FirstSteps } from '../../../src/features/dashboard';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<FirstSteps />);
  expect(renderedComponent.find('.dashboard-first-steps').length).toBe(1);
});

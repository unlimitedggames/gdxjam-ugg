import React from 'react';
import { shallow } from 'enzyme';
import { GroupActivity } from '../../../src/features/dashboard';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<GroupActivity />);
  expect(renderedComponent.find('.dashboard-group-activity').length).toBe(1);
});

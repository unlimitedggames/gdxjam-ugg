import React from 'react';
import { shallow } from 'enzyme';
import { GroupActivityEntry } from '../../../src/features/dashboard';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<GroupActivityEntry />);
  expect(renderedComponent.find('.dashboard-group-activity-entry').length).toBe(1);
});

import React from 'react';
import { shallow } from 'enzyme';
import { DefaultPage } from '../../../src/features/estates/DefaultPage';

describe('estates/DefaultPage', () => {
  it('renders node with correct class name', () => {
    const props = {
      estates: {},
      actions: {},
    };
    const renderedComponent = shallow(
      <DefaultPage {...props} />
    );

    expect(
      renderedComponent.find('.estates-default-page').length
    ).toBe(1);
  });
});

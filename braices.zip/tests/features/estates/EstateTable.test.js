import React from 'react';
import { shallow } from 'enzyme';
import { EstateTable } from '../../../src/features/estates';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<EstateTable />);
  expect(renderedComponent.find('.estates-estate-table').length).toBe(1);
});

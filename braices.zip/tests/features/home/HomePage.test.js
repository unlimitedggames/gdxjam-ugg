import React from 'react';
import { shallow } from 'enzyme';
import { HomePage } from '../../../src/features/home';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<HomePage />);
  expect(renderedComponent.find('.home-home-page').length).toBe(1);
});

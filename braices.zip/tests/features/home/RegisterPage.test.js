import React from 'react';
import { shallow } from 'enzyme';
import { RegisterPage } from '../../../src/features/home';

it('renders node with correct class name', () => {
  const renderedComponent = shallow(<RegisterPage />);
  expect(renderedComponent.find('.home-register-page').length).toBe(1);
});

export default function interopDefault(m: any): any;

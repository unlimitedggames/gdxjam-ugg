import Anchor from './Anchor';
export { AnchorProps } from './Anchor';
export { AnchorLinkProps } from './AnchorLink';
export default Anchor;

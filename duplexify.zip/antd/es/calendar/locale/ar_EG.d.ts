import ar_EG from '../../date-picker/locale/ar_EG';
export default ar_EG;

import el_GR from '../../date-picker/locale/el_GR';
export default el_GR;

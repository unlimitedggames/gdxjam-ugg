import et_EE from '../../date-picker/locale/et_EE';
export default et_EE;

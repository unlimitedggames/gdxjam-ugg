import fa_IR from '../../date-picker/locale/fa_IR';
export default fa_IR;

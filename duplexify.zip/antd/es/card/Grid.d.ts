import * as React from 'react';
export interface CardGridProps {
    prefixCls?: string;
    style?: React.CSSProperties;
    className?: string;
}
declare const _default: (props: CardGridProps) => JSX.Element;
export default _default;

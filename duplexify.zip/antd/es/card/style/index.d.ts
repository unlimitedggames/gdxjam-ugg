import '../../style/index.less';
import './index.less';
import '../../tabs/style';

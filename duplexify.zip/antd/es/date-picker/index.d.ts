import { DatePickerDecorator } from './interface';
declare const _default: DatePickerDecorator;
export default _default;

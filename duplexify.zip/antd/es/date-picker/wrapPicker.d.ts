import * as React from 'react';
export default function wrapPicker(Picker: React.ComponentClass<any>, defaultFormat?: string): any;

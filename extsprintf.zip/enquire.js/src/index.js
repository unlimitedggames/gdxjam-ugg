var MediaQueryDispatch = require('./MediaQueryDispatch');
module.exports = new MediaQueryDispatch();

/* eslint global-require: 0 */
module.exports = require('./ReactSixteenAdapter');

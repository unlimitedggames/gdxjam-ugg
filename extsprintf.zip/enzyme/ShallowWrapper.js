module.exports = require('./build/ShallowWrapper').default;

"use strict";

module.exports = function () {
	var cosh = Math.cosh;
	if (typeof cosh !== "function") return false;
	return cosh(1) === 1.5430806348152437;
};

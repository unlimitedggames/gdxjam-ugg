"use strict";

module.exports = require("./is-implemented")()
	? String.prototype.contains
	: require("./shim");

var Document = require('./document.js');

module.exports = new Document();

export { default } from './assignInWith.js'

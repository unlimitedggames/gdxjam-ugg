import clamp from './clamp.js';
import inRange from './inRange.js';
import random from './random.js';

export default {
  clamp, inRange, random
};

Replace Lodash with two tiny packages (#2 by @nightwolfz)

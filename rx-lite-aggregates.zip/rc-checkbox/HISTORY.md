# 2.1.0

Add focus() blur() and autoFocus.

# 1.5.0

- Refactor dom structure for better focus style.

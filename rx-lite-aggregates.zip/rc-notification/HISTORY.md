## 2.0.0

- [Beack Change] Remove wrapper span element when just single notification. [#17](https://github.com/react-component/notification/pull/17)

## 1.4.0

- Added `getContainer` property.

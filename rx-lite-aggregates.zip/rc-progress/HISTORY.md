# History

---

## 2.2.0
- when circle percent == 0, make stroke not visible

## 2.1.0
- Add `gapDegree` `gapPosition` props.

## 2.0.0

- refactor code
- Add `prefixCls` `className` `style` props.
- Add `strokeLinecap` for shape of end in progress bar.

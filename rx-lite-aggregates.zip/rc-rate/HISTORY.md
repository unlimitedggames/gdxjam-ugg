## 2.4.0

- Add allowClear support.

## 2.3.0

- Add keyboard support.
- Add focus() blur() and autoFocus.

## 2.1.0

- Fix typo `charactor` to `character`.

## 2.0.0

- Add `character`.
- Add `className`.
- Add `onHoverChange(value)`.

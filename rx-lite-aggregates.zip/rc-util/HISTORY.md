# History
----

## 3.4.0 / 2016-08-16

- add getScrollBarSize


## 3.3.0 / 2016-07-18

- add getContainerRenderMixin

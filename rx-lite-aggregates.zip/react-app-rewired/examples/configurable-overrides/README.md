# Example with costom-overrides location

```
npm pack ../../ | xargs npm install
npm start
```
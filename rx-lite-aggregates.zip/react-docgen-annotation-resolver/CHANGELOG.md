1.0.0 / 2017-07-13
==================
- Initial Commit - the resolver currently finds export declarations tagged with
  the `@component` annotation, and returns them to react-docgen.

# react-docgen-annotation-resolver

Parse `@component` annotated export as a react component.

Built with [`styled-components`][sc] in mind.

## *BETA*
While this does add exported paths with the `@component` annotation to
react-docgen, react-docgen is not able to grab properties off those components.
This does not actually work for styled-components yet.

[sc]: https://styled-components.com

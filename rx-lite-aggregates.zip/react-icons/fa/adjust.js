
import React from 'react'
import Icon from 'react-icon-base'

const FaAdjust = props => (
    <Icon viewBox="0 0 40 40" {...props}>
        <g><path d="m20.1 32.1v-24.2q-3.3 0-6.1 1.6t-4.4 4.4-1.6 6.1 1.6 6.1 4.4 4.4 6.1 1.6z m17.2-12.1q0 4.7-2.3 8.6t-6.3 6.2-8.6 2.3-8.6-2.3-6.2-6.2-2.3-8.6 2.3-8.6 6.2-6.2 8.6-2.3 8.6 2.3 6.3 6.2 2.3 8.6z"/></g>
    </Icon>
)

export default FaAdjust

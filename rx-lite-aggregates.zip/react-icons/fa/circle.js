
import React from 'react'
import Icon from 'react-icon-base'

const FaCircle = props => (
    <Icon viewBox="0 0 40 40" {...props}>
        <g><path d="m37.3 20q0 4.7-2.3 8.6t-6.3 6.2-8.6 2.3-8.6-2.3-6.2-6.2-2.3-8.6 2.3-8.6 6.2-6.2 8.6-2.3 8.6 2.3 6.3 6.2 2.3 8.6z"/></g>
    </Icon>
)

export default FaCircle

sleep 3
echo 3 1>&2
echo 2
false
